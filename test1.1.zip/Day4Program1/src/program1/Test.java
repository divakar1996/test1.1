package program1;

import java.util.Scanner;

public class Test {
	public static void main(String args[]) {
		int input1;
		String input2[];
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please Enter the no Of bowlers :");
		input1 = scanner.nextInt();

		BowlerAverageCalculate bowlerAverageCalculate = new BowlerAverageCalculate();
		input2 = new String[input1];
			for (int i = 0; i < input2.length; i++) {
				input2[i] = scanner.next();

			}
		

	
		bowlerAverageCalculate.calculate(input1,input2);

		scanner.close();

	}

}
