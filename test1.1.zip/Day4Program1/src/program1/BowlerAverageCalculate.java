package program1;

import java.util.Scanner;

public class BowlerAverageCalculate {

	private int count;

	private int sum;
	private double avg;

	Scanner scanner = new Scanner(System.in);

	public void calculate(int input1, String[] input2) {
		int i;
		for (i = 0; i < input1; i++) {
			char[] a = input2[i].toCharArray();
			int chageIntoInt[] = new int[a.length];
			for (int j = 0; j < chageIntoInt.length; j++) {
				chageIntoInt[j] = Character.getNumericValue(a[j]);
				sum += chageIntoInt[j];
			}
			avg = (double) (sum / a.length);
			if (avg >= 5) {
				count++;
			}

		}
		System.out.println("No of bowlers who selected in the list :" + count);

	}
}